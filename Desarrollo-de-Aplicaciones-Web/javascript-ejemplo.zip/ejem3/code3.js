var numbers = [3, 4, 4, 2];

document.write(numbers[5] + '<br>');

numbers[7] = 4;

document.write(numbers[7] + '<br>');

for (var i = 0; i < numbers.length; i++) {
    document.write(numbers[i] + ",");
}

var moreNumbers;

console.log(moreNumbers[7]);
