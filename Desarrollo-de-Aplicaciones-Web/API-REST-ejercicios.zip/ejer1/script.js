$(document).ready(function () {

    $("#add-button").click(function () {
        var value = $('#value-input').val();

        $('#info').html("<img src='spinner.gif'/>");

        $.ajax({
            url: "https://www.googleapis.com/books/v1/volumes?q=intitle:" + value
        }).done(function (data) {

            $('#info').empty()

            for (var i = 0; i < data.items.length; i++) {

                var book = data.items[i].volumeInfo;

                $('#info').append("<div><h3>" + book.title + "</h3>" +
                    "<p>" + book.description + "</p></div>");
            }
        });
    })
})